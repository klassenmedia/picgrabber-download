"""Standalone review server for customers.

Runs the customer-facing part of PicGrabber on Python's standard library
alone: no Flask, no FFmpeg, no installation beyond Python itself. That keeps
the customer's setup to a single double-click.

Only the endpoints the review mode actually uses are implemented. Cutting,
frame grabbing and EDL export stay in app.py, since those need FFmpeg and
only the editor runs them.
"""

import os
import re
import json
import base64
import binascii
import datetime
import mimetypes
import subprocess
import webbrowser
import threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote
from pathlib import Path

VIDEO_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv", ".mts", ".m2ts"}
BASE_DIR = Path(__file__).resolve().parent
CHUNK = 1024 * 1024


def normalize_sequence(seq, folder=""):
    """Fill in fields missing from older _sequences.json files."""
    seq.setdefault("rating", None)
    seq.setdefault("comment", "")
    seq.setdefault("created", "")

    path = seq.get("path", "")
    if not seq.get("name"):
        seq["name"] = os.path.basename(path)
    if not seq.get("rel"):
        seq["rel"] = os.path.relpath(path, folder) if folder and path.startswith(folder) else seq["name"]
    if "duration" not in seq:
        seq["duration"] = max(0.0, seq.get("out", 0) - seq.get("in", 0))
    return seq


class Handler(BaseHTTPRequestHandler):
    # Keep the console readable for a non-technical user.
    def log_message(self, *args):
        pass

    # ── helpers ──────────────────────────────────────────
    def send_json(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", 0))
        if not length:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}

    # ── routes ───────────────────────────────────────────
    def do_GET(self):
        url = urlparse(self.path)
        query = parse_qs(url.query)
        route = url.path

        if route == "/":
            return self.serve_index()
        if route == "/videos":
            return self.list_videos(query.get("folder", [""])[0])
        if route == "/stream":
            return self.stream_video(query.get("path", [""])[0])
        if route == "/load_sequences":
            return self.load_sequences(query.get("folder", [""])[0])
        if route == "/pick_folder":
            return self.pick_folder()
        if route == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
            return
        self.send_json({"error": "Unbekannte Adresse"}, 404)

    def do_POST(self):
        route = urlparse(self.path).path
        data = self.read_json()

        if route == "/save_sequences":
            return self.save_sequences(data)
        if route == "/export_review":
            return self.export_review(data)
        if route == "/save_frame":
            return self.save_frame(data)
        # Editor-only endpoints: report clearly instead of failing silently.
        if route in ("/grab_frame", "/export_edl", "/export_clips", "/import_review"):
            return self.send_json(
                {"error": "Diese Funktion ist in der Sichtungs-Version nicht enthalten."}, 400)
        self.send_json({"error": "Unbekannte Adresse"}, 404)

    # ── implementations ──────────────────────────────────
    def serve_index(self):
        try:
            html = (BASE_DIR / "templates" / "index.html").read_bytes()
        except OSError:
            self.send_json({"error": "index.html fehlt"}, 500)
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(html)))
        self.end_headers()
        self.wfile.write(html)

    def list_videos(self, folder):
        folder = unquote(folder).strip()
        if not folder or not os.path.isdir(folder):
            return self.send_json({"error": "Ordner nicht gefunden"}, 400)

        videos = []
        for root, _, files in os.walk(folder):
            for f in sorted(files):
                if Path(f).suffix.lower() in VIDEO_EXTENSIONS:
                    full = os.path.join(root, f)
                    videos.append({
                        "name": f,
                        "rel": os.path.relpath(full, folder),
                        "path": full,
                        "size_mb": round(os.path.getsize(full) / 1024 / 1024, 1),
                    })
        videos.sort(key=lambda x: x["rel"])
        self.send_json({"videos": videos, "count": len(videos)})

    def stream_video(self, path):
        path = unquote(path)
        if not path or not os.path.isfile(path):
            self.send_response(404)
            self.end_headers()
            return

        size = os.path.getsize(path)
        ctype = mimetypes.guess_type(path)[0] or "video/mp4"
        rng = self.headers.get("Range")

        # Seeking in the timeline only works if range requests are honoured.
        start, end = 0, size - 1
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)", rng)
            if m:
                if m.group(1):
                    start = int(m.group(1))
                if m.group(2):
                    end = int(m.group(2))
        end = min(end, size - 1)
        if start > end:
            self.send_response(416)
            self.send_header("Content-Range", f"bytes */{size}")
            self.end_headers()
            return

        length = end - start + 1
        self.send_response(206 if rng else 200)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        if rng:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()

        try:
            with open(path, "rb") as f:
                f.seek(start)
                remaining = length
                while remaining > 0:
                    chunk = f.read(min(CHUNK, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass  # Normal when the player seeks or the tab closes.

    def pick_folder(self):
        """Open the native macOS folder chooser.

        Browsers never hand out a real filesystem path for a picked folder,
        so the dialog has to come from this side. The script is a fixed
        string with no interpolated input.
        """
        script = (
            'try\n'
            '  set f to choose folder with prompt "Ordner auswählen"\n'
            '  return POSIX path of f\n'
            'on error number -128\n'
            '  return ""\n'
            'end try'
        )
        try:
            result = subprocess.run(["osascript", "-e", script],
                                    capture_output=True, text=True, timeout=180)
        except (OSError, subprocess.SubprocessError):
            return self.send_json({"error": "Auswahl nicht möglich"}, 500)

        path = result.stdout.strip().rstrip("/")
        if not path or not os.path.isdir(path):
            return self.send_json({"ok": False, "cancelled": True})
        self.send_json({"ok": True, "path": path})

    def load_sequences(self, folder):
        folder = unquote(folder)
        path = os.path.join(folder, "_sequences.json")
        if not os.path.isfile(path):
            return self.send_json({"sequences": []})
        try:
            with open(path, encoding="utf-8") as f:
                sequences = json.load(f)
        except (OSError, ValueError):
            return self.send_json({"sequences": []})
        self.send_json({"sequences": [normalize_sequence(s, folder) for s in sequences]})

    def save_sequences(self, data):
        folder = data.get("output_folder", "")
        if not folder or not os.path.isdir(folder):
            return self.send_json({"error": "Ordner nicht gefunden"}, 400)
        sequences = [normalize_sequence(s, folder) for s in data.get("sequences", [])]
        path = os.path.join(folder, "_sequences.json")
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(sequences, f, indent=2, ensure_ascii=False)
        except OSError as e:
            return self.send_json({"error": f"Speichern fehlgeschlagen: {e}"}, 500)
        self.send_json({"ok": True, "path": path})

    def save_frame(self, data):
        """Store a still the browser drew from the video onto a canvas.

        Doing it browser-side keeps FFmpeg out of the customer's install;
        the picture is whatever the player currently shows.
        """
        target = (data.get("target_folder") or "").strip()
        if not target:
            target = os.path.join(os.path.expanduser("~/Desktop"), "Bilder")
        elif not os.path.isabs(os.path.expanduser(target)):
            # "Desktop/Meine Bilder" should land in the home folder,
            # not wherever the server happens to have been started.
            target = os.path.join(os.path.expanduser("~"), target)

        target = os.path.abspath(os.path.expanduser(target))
        if not os.path.isdir(target):
            try:
                os.makedirs(target, exist_ok=True)
            except OSError as e:
                return self.send_json({"error": f"Ordner nicht nutzbar: {e}"}, 400)

        image = data.get("image", "")
        if "," in image:
            image = image.split(",", 1)[1]
        try:
            raw = base64.b64decode(image, validate=True)
        except (binascii.Error, ValueError):
            return self.send_json({"error": "Bild konnte nicht gelesen werden"}, 400)
        if not raw:
            return self.send_json({"error": "Bild ist leer"}, 400)

        # Build the filename from the video name and timestamp, but keep
        # only the basename: a crafted name must not escape the target folder.
        stem = Path(os.path.basename(data.get("video_name", "frame"))).stem or "frame"
        stem = re.sub(r"[^\w\-. ]", "_", stem).strip() or "frame"
        ts = float(data.get("timestamp", 0))
        base = f"{stem}_{int(ts // 60):02d}m{ts % 60:06.3f}s".replace(".", "-")

        path = os.path.join(target, f"{base}.jpg")
        counter = 2
        while os.path.exists(path):
            path = os.path.join(target, f"{base}_{counter}.jpg")
            counter += 1

        try:
            with open(path, "wb") as f:
                f.write(raw)
        except OSError as e:
            return self.send_json({"error": f"Speichern fehlgeschlagen: {e}"}, 500)

        self.send_json({"ok": True, "saved": path, "filename": os.path.basename(path)})

    def export_review(self, data):
        folder = data.get("output_folder", "")
        sequences = data.get("sequences", [])
        if not folder or not os.path.isdir(folder):
            return self.send_json({"error": "Ordner nicht gefunden"}, 400)
        if not sequences:
            return self.send_json({"error": "Keine Sequenzen vorhanden"}, 400)

        # Freeze list position as `nr` so "Sequenz 7" stays meaningful
        # in comments even after the list is re-sorted later.
        entries = []
        for i, seq in enumerate(sequences):
            s = normalize_sequence(dict(seq), folder)
            entries.append({
                "nr": i + 1, "rel": s["rel"], "name": s["name"],
                "in": s["in"], "out": s["out"], "duration": s["duration"],
                "rating": s["rating"], "comment": s["comment"],
            })

        good = sum(1 for e in entries if e["rating"] == "gut")
        bad = sum(1 for e in entries if e["rating"] == "schlecht")
        folder_name = os.path.basename(os.path.normpath(folder)) or "Material"

        review = {
            "version": 1,
            "created": datetime.datetime.now().isoformat(timespec="seconds"),
            "folder_name": folder_name,
            "general_comment": data.get("general_comment", ""),
            "stats": {"total": len(entries), "gut": good, "schlecht": bad,
                      "offen": len(entries) - good - bad},
            "sequences": entries,
        }

        safe = "".join(c for c in folder_name if c.isalnum() or c in " -_").strip()
        filename = f"Review_{safe or 'Material'}_{datetime.date.today().isoformat()}.json"
        path = os.path.join(folder, filename)
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(review, f, indent=2, ensure_ascii=False)
        except OSError as e:
            return self.send_json({"error": f"Speichern fehlgeschlagen: {e}"}, 500)

        self.send_json({"ok": True, "path": path, "filename": filename, "stats": review["stats"]})


def open_browser(url):
    """Open the user's default browser.

    macOS `open` honours the default browser reliably; webbrowser.open can
    fall back to something else depending on how Python was installed. Only
    used as a fallback here, and never on a URL from outside this process.
    """
    try:
        subprocess.run(["open", url], check=True, timeout=10)
        return
    except (OSError, subprocess.SubprocessError):
        pass
    try:
        webbrowser.open(url)
    except webbrowser.Error:
        print(f"Bitte im Browser öffnen: {url}")


def main():
    port = int(os.environ.get("PORT", 7070))
    # Bind to localhost only: this is a personal tool, not a network service.
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    url = f"http://localhost:{port}/?mode=kunde"
    threading.Timer(1.5, open_browser, args=(url,)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nBeendet.")


if __name__ == "__main__":
    main()
