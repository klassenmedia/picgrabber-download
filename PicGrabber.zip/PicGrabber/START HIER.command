#!/bin/bash
# PicGrabber — die einzige Datei, die der Kunde anklickt.
#
# Prueft zuerst, ob der Rechner ueberhaupt geeignet ist, und sagt das klar,
# BEVOR irgendetwas installiert wird. Danach laeuft alles ohne Rueckfragen
# durch bis zum offenen Browser.

cd "$(dirname "$0")" || exit 1
PROG="programm"

# macOS quarantines everything unzipped from a download, which makes
# Gatekeeper block this script on the first double-click.
xattr -dr com.apple.quarantine . 2>/dev/null
chmod +x "$0" 2>/dev/null

clear
cat <<'BANNER'

  ==============================================
     PicGrabber
     Bilder aus deinen Videos
  ==============================================

BANNER

ende_mit_fehler() {
  echo ""
  echo "  =============================================="
  echo "     ❌ $1"
  echo "  =============================================="
  echo ""
  [[ -n "$2" ]] && { echo "     $2"; echo ""; }
  echo "     Bitte diesen Text abfotografieren"
  echo "     und an Andreas schicken."
  echo ""
  read -r -p "     [Enter zum Schließen]"
  exit 1
}

# ── Vorab: Laeuft das hier ueberhaupt? ────────────
# Diese Pruefungen laufen VOR jeder Installation, damit niemand erst
# zehn Minuten wartet und dann erfaehrt, dass es nicht geht.

if [[ "$(uname -s)" != "Darwin" ]]; then
  ende_mit_fehler "Dieses Programm läuft nur auf einem Mac." \
                  "Auf Windows funktioniert es leider nicht."
fi

MACOS_VER=$(sw_vers -productVersion 2>/dev/null)
MACOS_MAJOR=${MACOS_VER%%.*}
if [[ -n "$MACOS_MAJOR" ]] && [[ "$MACOS_MAJOR" -lt 11 ]]; then
  ende_mit_fehler "Dein macOS ist zu alt (Version $MACOS_VER)." \
                  "Nötig ist macOS 11 oder neuer."
fi

if [[ ! -f "$PROG/sichtung.py" ]]; then
  ende_mit_fehler "Das Programm ist unvollständig." \
                  "Bitte das ZIP nochmal komplett entpacken."
fi

# ── Python finden ─────────────────────────────────
# `python3` on a fresh Mac is only a stub that opens the Xcode installer,
# so probe for an interpreter that actually runs instead of trusting PATH.
find_python() {
  for p in /Library/Frameworks/Python.framework/Versions/Current/bin/python3 \
           /usr/local/bin/python3 /opt/homebrew/bin/python3 \
           "$(command -v python3 2>/dev/null)"; do
    [[ -x "$p" ]] && "$p" -c "import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)" 2>/dev/null \
      && { echo "$p"; return 0; }
  done
  return 1
}

PYTHON="$(find_python)"

if [[ -z "$PYTHON" ]]; then
  echo "  Beim ersten Start wird einmalig etwas eingerichtet."
  echo "  Das dauert ungefähr zwei Minuten."
  echo ""
  echo "  Gleich fragt der Mac nach deinem Passwort."
  echo "  Beim Tippen bleibt die Zeile leer – das ist normal."
  echo ""

  curl -sf --max-time 10 -o /dev/null "https://www.python.org" 2>/dev/null \
    || ende_mit_fehler "Keine Internetverbindung." \
                       "Beim ersten Start wird sie einmalig gebraucht."

  echo "  Wird geladen …"
  PKG="${TMPDIR:-/tmp}/picgrabber_python.pkg"
  curl -fL --progress-bar -o "$PKG" \
    "https://www.python.org/ftp/python/3.12.7/python-3.12.7-macos11.pkg" \
    || ende_mit_fehler "Der Download hat nicht geklappt."

  echo ""
  echo "  Wird eingerichtet – bitte Passwort eingeben:"
  sudo installer -pkg "$PKG" -target / >/dev/null \
    || ende_mit_fehler "Die Einrichtung hat nicht geklappt."
  rm -f "$PKG"

  PYTHON="$(find_python)"
  [[ -z "$PYTHON" ]] && ende_mit_fehler "Die Einrichtung ist unvollständig."
  echo ""
fi

# ── Freien Port suchen ────────────────────────────
PORT=7070
while lsof -ti:$PORT &>/dev/null && [[ $PORT -lt 7090 ]]; do
  PORT=$((PORT + 1))
done
[[ $PORT -ge 7090 ]] && ende_mit_fehler "Es läuft schon zu viel auf diesem Mac." \
                                        "Bitte den Mac neu starten und nochmal versuchen."

cat <<INFO
  ==============================================
     ✅ Alles bereit
  ==============================================

     Der Browser öffnet sich in wenigen Sekunden.

     Falls nicht, diese Adresse im Browser öffnen:
     http://localhost:$PORT/?mode=kunde

  ----------------------------------------------

     ⚠️  Dieses Fenster bitte OFFEN LASSEN,
         solange du arbeitest.

     Zum Beenden: Fenster einfach schließen.

INFO

cd "$PROG" || ende_mit_fehler "Das Programm wurde nicht gefunden."
PORT=$PORT "$PYTHON" sichtung.py
