#!/bin/bash
# PicGrabber — Doppelklick zum Starten (Sichtungs-Version für Kunden)
#
# Braucht nur Python. Kein Homebrew (das zieht die Xcode Command Line Tools
# nach: mehrere GB, eigene Dialoge), kein FFmpeg (nur der Editor schneidet,
# der Kunde sichtet bloß) und keine Zusatzpakete — sichtung.py kommt mit
# Pythons Standardbibliothek aus.

cd "$(dirname "$0")" || exit 1

# macOS quarantines everything unzipped from a download, which makes
# Gatekeeper block this script on the first double-click.
xattr -dr com.apple.quarantine . 2>/dev/null
chmod +x "$0" 2>/dev/null

clear
cat <<'BANNER'
==================================================
   PicGrabber – Material sichten
==================================================
BANNER
echo ""

abbruch() {
  echo ""
  echo "=================================================="
  echo "   ❌ $1"
  echo "=================================================="
  echo ""
  echo "   Bitte diesen Text abfotografieren"
  echo "   und an Andreas schicken."
  echo ""
  read -r -p "   [Enter zum Beenden]"
  exit 1
}

# ── Python finden ─────────────────────────────────
# `python3` on a fresh Mac is only a stub that opens the Xcode installer,
# so probe for an interpreter that actually runs instead of trusting PATH.
find_python() {
  for p in /Library/Frameworks/Python.framework/Versions/Current/bin/python3 \
           /usr/local/bin/python3 /opt/homebrew/bin/python3 \
           "$(command -v python3 2>/dev/null)"; do
    [[ -x "$p" ]] && "$p" -c "import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)" 2>/dev/null \
      && { echo "$p"; return 0; }
  done
  return 1
}

PYTHON="$(find_python)"

if [[ -z "$PYTHON" ]]; then
  echo "Beim ersten Start wird einmalig Python installiert."
  echo "Das dauert etwa 2 Minuten."
  echo ""
  echo "  1. Es wird nach deinem Mac-Passwort gefragt."
  echo "     Beim Tippen bleibt die Zeile leer – das ist normal."
  echo "  2. Danach startet PicGrabber automatisch."
  echo ""
  read -r -p "  [Enter zum Fortfahren]"
  echo ""

  curl -sf --max-time 10 -o /dev/null "https://www.python.org" \
    || abbruch "Keine Internetverbindung."

  echo "📦 Python wird geladen…"
  PKG="$TMPDIR/picgrabber_python.pkg"
  curl -fL --progress-bar -o "$PKG" \
    "https://www.python.org/ftp/python/3.12.7/python-3.12.7-macos11.pkg" \
    || abbruch "Python konnte nicht geladen werden."

  echo ""
  echo "📦 Python wird installiert – bitte Passwort eingeben:"
  sudo installer -pkg "$PKG" -target / || abbruch "Python konnte nicht installiert werden."
  rm -f "$PKG"

  PYTHON="$(find_python)"
  [[ -z "$PYTHON" ]] && abbruch "Python wurde installiert, aber nicht gefunden."
  echo ""
fi
echo "✅ Bereit"

# ── Freien Port suchen ────────────────────────────
PORT=7070
while lsof -ti:$PORT &>/dev/null && [[ $PORT -lt 7090 ]]; do
  PORT=$((PORT + 1))
done
[[ $PORT -ge 7090 ]] && abbruch "Kein freier Port gefunden."

echo ""
echo "=================================================="
echo "   ✅ Der Browser öffnet sich gleich"
echo "=================================================="
echo ""
echo "   Adresse: http://localhost:$PORT/?mode=kunde"
echo ""
echo "   ⚠️  Dieses Fenster bitte GEÖFFNET LASSEN,"
echo "       solange du das Material sichtest."
echo ""
echo "   Zum Beenden: Fenster schließen."
echo ""

PORT=$PORT "$PYTHON" sichtung.py
